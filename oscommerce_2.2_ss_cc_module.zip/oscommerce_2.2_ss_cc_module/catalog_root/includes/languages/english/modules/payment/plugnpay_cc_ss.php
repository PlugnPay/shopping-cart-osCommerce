<?php
/*
  $Id: plugnpay_cc_ss.php 1739 2008-12-27 00:52:16Z hpdl $

  osCommerce (Open Source Commerce)
  http://www.oscommerce.com

  Copyright (c) 2009 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_TEXT_TITLE', 'PlugnPay Credit Card SS');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_TEXT_PUBLIC_TITLE', 'Credit Card (Processed by PlugnPay)');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.plugnpay.com" target="_blank" style="text-decoration: underline; font-weight: bold;">Visit PlugnPay.com Website</a>');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_ERROR_TITLE', 'There has been an error processing your credit card');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_ERROR_VERIFICATION', 'The credit card transaction could not be verified with this order. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_ERROR_DECLINED', 'This credit card transaction has been declined. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_ERROR_PROBLEM', 'There was a problem processing your credit card transaction. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_ERROR_FRAUD', 'This credit card transaction has been rejected. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_ERROR_GENERAL', 'Please try again and if problems persist, please try another payment method.');
?>
