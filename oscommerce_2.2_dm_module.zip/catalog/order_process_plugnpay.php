<?PHP
// For use with PlugnPay osCommerce payment module
// Last Updated: 09/29/04

if ($HTTP_SERVER_VARS) {
  $ip = $HTTP_SERVER_VARS['REMOTE_ADDR'];
  $method = $HTTP_SERVER_VARS['REQUEST_METHOD'];
  $server_name = $HTTP_SERVER_VARS['SERVER_NAME'];
}
else {
  $ip = $_SERVER['REMOTE_ADDR'];
  $method = $SERVER['REQUEST_METHOD'];
  $server_name = $_SERVER['SERVER_NAME'];
}
$match = ereg("^209\.51\.176\.", $ip);

if ($HTTP_SERVER_VARS) {
  $PHPSESSID = $HTTP_POST_VARS["PHPSESSID"];
  $shipinfo = $HTTP_POST_VARS["shipinfo"];
  $shipping_method = $HTTP_POST_VARS["shipping_method"];
  $finalstatus = $HTTP_POST_VARS["FinalStatus"];
  $oscsid = $HTTP_POST_VARS["osCsid"];
  $publisher_email = $HTTP_POST_VARS["publisher-email"];
}
else {
  $PHPSESSID = $_POST["PHPSESSID"];
  $shipinfo = $_POST["shipinfo"];
  $shipping_method = $_POST["shipping_method"];
  $finalstatus = $_POST["FinalStatus"];
  $oscsid = $_POST["osCsid"];
  $publisher_email = $_POST["publisher-email"];
}

if ($publisher_email == '') {
  $publisher_email = 'us'; 
}

if ($method != "POST") {
  echo "<b/>Invalid Method</b/>";
  echo "<br/>POST method must be used.";
  exit();
}

if ($match != 1){
  echo "<b/>Un-Authorized Purchase</b/>";
  echo "<br/>IP address ($ip) does match the IP of the expected internet location.";
  echo "<br/>To finalize your transaction, please purchase properly.";
  echo "<br/>If you believe this response was in error, please contact $publisher_email for support assistance.";
  exit();
}

if ($finalstatus != "success") {
  echo "<b/>Declined or Problem Purchase</b/> ($finalstatus)";
  echo "<br/>This purchase appears to have been declined or experienced a problem.";
  echo "<br/>To finalize your transaction, please purchase properly.";
  echo "<br/>If you believe this response was in error, please contact $publisher_email for support assistance.";
  exit();
}
?>

<html>
<body>
<center>
<div align="center">&nbsp;<br>&nbsp;</div>
<div align="center"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">To complete the final checkout process click on the Finish button below.</font><br>&nbsp;
</div>

<form method="POST" action="http://<?echo $server_name;?>/catalog/checkout_process.php" name="myForm">
  <div align="center">
    <input type="hidden" name="PHPSESSID" value="<?echo $PHPSESSID;?>">
    <input type="hidden" name="shipinfo" value="<?echo $shipinfo;?>">
    <input type="hidden" name="shipping_method" value="<?echo $shipping_method;?>">
    <input type="hidden" name="osCsid" value="<?echo $oscsid;?>">
    <input type="submit" name="submit" value="Finish">
  </div>
</form>

</center>
</body>
</html>

