=================================================
Plug 'n Pay - Direct Method
Payment Module for osCommerce 2.2
=================================================

***** IMPORTANT NOTES *****
This module is being provided "AS IS".  Limited technical support
assistance will be given to help diagnose/address problems with this
module.  The amount of support provided is up to PlugnPay's staff.

It is recommended if you experience a problem with this module, first
seek assistance through this module's readme file, then check with the
osCommerce community at 'www.oscommerce.com', and if you are still unable
to resolve the issue, contact us via PlugnPay's online helpdesk.

This module is intended to use your own server's SSL abilities and 
will ask the customer for all of their credit card info directly in the 
osCommerce interface.  The authorization will be done via PlugnPay's Direct 
Method.  It is intended to itemize the order in the PlugnPay system using 
available information from the cart.

If you want to change the behavior of this module, please feel free
to make the changes to the files yourself.  However, customized
osCommerce modules will not be provided support assistance.

In addition, you MUST have the 'Enable secure SSL/HTTPS connections'
option enabled in your osCommerce shopping cart to properly use this module.
This will also require you to have an SSL security certificate installed on
your web server.  If you don't have this, then download/use the Smart Screens
version of this module instead.
***************************

Installation:

For a default osCommerce installation, simply upload the provided files into
the 'catalog' folder and activate in the osCommerce admin area.

For a custom osCommerce installation, change all refferences of 'catalog' in
the module's .php scripts to the folder name where you actually installed the
shopping cart to.  Then upload the modified module to your custom folder where
you installed osCommerce to.


If you run into problems:

Check to be sure you actually uploaded the files in the correct folder.

Check the uploaded file's permissions:
-- .php files should be chmod 755
   (read/write/execute by owner, read/execute by all orders)
-- .gif files should be chmod 644
   (read/write by owner, read only by all orders)

If you allow online electronic check payments, you must be sure you have an 
electronic checking account setup with PlugnPay first, prior to accepting
online check payments through osCommerce.

These are the common issues found by our support staff. 


Some Processing Errors could include:

Invalid Method:

This module requires all Plug 'n Pay clients to use a POST method back to their 
site.  If you have a problem with the connection made from our gateway back to 
your shopping cart, please contact our technical support staff via the online 
helpdesk & request we switch your account from a GET (transition page) to the 
POST method for your connection back to your site.

Un-Authorized Purchase:

This means the IP address that is connecting to your 'order_process_plugnpay.php'
script is not from our server network.  It is likely someone is trying to trick
your shopping cart into believing an order is successful when it was not authorized
through our payment gateway.

Declined or Problem Purchase:

This means the order was not approved via our gateway.  It is likely someone is 
trying to trick your shopping cart in believing an order is successful when it was 
not authorized through our gateway successfully.

-----------------------------------------------------------------------------
Updates:

01/09/04
- Changed Title_Text tag to work with osCommerce v2.2.
  So, this change adds MasterCard, Visa Icons making it more
  clear and professional looking for visitors.  The module is
  now viewable in the easy screens control panel as well.
  Just upload all files in the right directories.

06/01/04
- Updated the 'order_process_plugnpay.php' script to only allow
  successful orders from the PlugnPay gateway to continue to be
  finalized.  This update stops a browser trick from being used
  to mark unauthorized transactions as approved in the cart.
  This update also addresses the default 'POST' success-link method
  the PlugnPay gateway uses; thus removing the need for merchants
  to request to have their account updated to use a GET method.

06/03/04
- Updated all the scripts to itemize the order, use the billing/contact
  information that is already in the cart and to properly address 
  several other issues with the shopping cart and how it uses our
  payment gateway.

08/24/04
- Applied small fix to the 'plugnpay.php' script to address a month name listing
  issue.

09/27/04
- Updated the 'order_process_plugnpay.php' script to address how PHP stores
  environment information & how it should be properly called.

09/29/04
- Cleaned up payment module's admin area menu & checkout interface
- Added code to admin interface to allow checkboxes in admin area menus
  (needed for newly updated admin interface layout)
- Added Electronic Check payment option
  (requires an electronic checking account to be established with PnP first.)
- Added additional card types (Amex & Discover)
- Added client identification tags to make it easier to diagnose which osCommerce
  module you are using.

10/15/04
- added admin option to have osCommerce send PnP 2-letter states where possible
- refined delete process when installing the module in the osCommerce admin area

10/21/04
- added support for multi-currency authorizations
  [for those merchant processors which support this ability]

01/26/05
- fixed a small parse error, which could prevent the module from loading.
- updated this doc for installing the module to a custom osCommerce folder.

01/27/05
- fixed issue with duplicate order-id being provided twice

01/18/06
- adjusted code to use the new 'auth.cgi' shared payment script, instead of using the
  old 'username.cgi' payment script.

