=================================================
Plug 'n Pay - Smart Screens Method
Payment Module for osCommerce 2.2
=================================================

***** IMPORTANT NOTES *****
This module is being provided "AS IS".  Limited technical support assistance will
be given to help diagnose/address problems with this module.  The amount of support
provided is up to PlugnPay's staff.

It is recommended if you experience a problem with this module, first seek assistance
through this module's readme file, then check with the osCommerce community at
'www.oscommerce.com', and if you are still unable to resolve the issue, contact us
via PlugnPay's Online Helpdesk.

This module is used without having your own server's SSL abilities. We will ask the
customer for all of their credit card info on our SSL secured billing page on our
secured servers.  The authorization will be done via PlugnPay's Smart Screens payment
method.  The module is intended to itemize the order in the PlugnPay system using
available information from the cart.

If you want to change the behavior of this module, please feel free to make changes
to the files yourself.  However, customized osCommerce modules will not be provided
support assistance.

In addition, you should have the 'Enable secure SSL/HTTPS connections' option disabled
in your osCommerce shopping cart to properly use this module. If you have your own SSL
security certificate, download/use the Direct Method version of this module instead.
***************************

Installation:

For a default osCommerce installation, simply upload the provided files into
the 'catalog' folder and activate in the osCommerce admin area.

For a custom osCommerce installation, change all refferences of 'catalog' in
the module's .php scripts to the folder name where you actually installed the
shopping cart to.  Then upload the modified module to your custom folder where
you installed osCommerce to.


If you run into problems:

Check to be sure you actually uploaded the files in the correct folder.

Check the uploaded file's permissions:
-- .php files should be chmod 755
   (read/write/execute by owner, read/execute by all others)
-- .gif files should be chmod 644
   (read/write by owner, read only by all others)

If you allow online electronic check payments, you must be sure you have an electronic
checking account setup with PlugnPay prior to accepting online check payments through
osCommerce.

These are the common issues found by our support staff.


Some Processing Errors could include:

Invalid Method:

This module requires all Plug 'n Pay clients to use a POST method back to their site.
If you have a problem with the connection made from our gateway back to your shopping
cart, please contact our technical support staff via the online helpdesk & request we
switch your account from a GET (transition page) to the POST method for your connection
back to your site.

Un-Authorized Purchase:

This means the IP address that is connecting to your 'order_process_plugnpay.php'
script is not from our server network.  It is likely someone is trying to trick your
shopping cart into believing an order is successful when it was not authorized through
our payment gateway.

Declined or Problem Purchase:

This means the order was not approved via our gateway.  It is likely someone is trying
to trick your shopping cart into believing an order is successful when it was not
authorized through our gateway successfully.

-----------------------------------------------------------------------------
Updates:

01/09/04
- Changed Title_Text tag to work with osCommerce v2.2.
  So, this change adds MasterCard, Visa Icons making it more clear and
  professional looking for visitors.
- The module is now viewable in the easy screens control panel as well.
- Just upload all files in the right directories.

06/01/04
- Updated the 'order_process_plugnpay.php' script to only allow successful orders from
  the PlugnPay gateway to continue to be finalized.  This update stops a browser trick
  from being used to mark unauthorized transactions as approved in the cart. This update
  also addresses the default 'POST' success-link method the PlugnPay gateway uses; thus
  removing the need for merchants to request to have their account updated to use a GET
  method.

06/03/04
- Updated all the scripts to itemize the order, use the billing/contact information that
  is already in the cart and to properly address several other issues with the shopping
  cart and how it uses our payment gateway.

09/27/04
- Updated the 'order_process_plugnpay.php' script to address how PHP stores environment
  information & how it should be properly called.

09/29/04
- Cleaned up payment module's admin area menu & checkout interfaces
- Added code to admin interface to allow checkboxes in admin area menus
  (needed for newly updated admin interface layout)
- Added Electronic Check payment option
  (requires an electronic checking account to be established with PnP first.)
- Added additional card types (Amex & Discover)
- Added client identification tags to make it easier to diagnose which
  osCommerce module you are using.

10/15/04
- refined delete process when installing the module in the osCommerce admin area

10/21/04
- added support for multi-currency authorizations
  [for those merchant processors which support this ability]

01/26/05
- updated this readme doc for how to install the module to a custom osCommerce folder.
- replaced 'checkout_process_plugnpay.php' with newer one from Direct Method version.

01/18/06
- adjusted code to use the new 'pay.cgi' shared payment script, instead of using the
  old 'usernamepay.cgi' payment script.

08/08/06
- fixed typo in 'REQUEST_METHOD' line of the order_process_plugnpay.php script.

09/02/10
- applied new PlugnPay server IP address to 'order_process_plugnpay.php'.
- fixed small bug with how 'card-allowed' value is generated in 'plugnpay.php'. 
 
