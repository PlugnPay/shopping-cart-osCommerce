<?php
/*
  $Id: plugnpay.php,v 0.9 2004/09/29 12:12:18 hpdl Exp $

  The Exchange Project - Community Made Shopping!
  http://www.theexchangeproject.org

  Copyright (c) 2004 The Exchange Project

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PLUGNPAY_TEXT_TITLE', 'PlugnPay');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_DESCRIPTION', 'PlugnPay Smart Screens');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_TYPE', 'Type:');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_CREDIT_CARD_OWNER', 'Name On Card:');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_CREDIT_CARD_NUMBER', 'Credit Card Number:');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_CREDIT_CARD_CVV', 'CVV/CVV2:');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_CREDIT_CARD_EXPIRES', 'Credit Card Expiry Date:');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_JS_CC_NUMBER', '* The credit card number must be at least ' . CC_NUMBER_MIN_LENGTH . ' characters.\n');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_JS_CC_OWNER', '* The owner\'s name of the credit card must be at least ' . CC_OWNER_MIN_LENGTH . ' characters.\n');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_ERROR_MESSAGE', 'There has been an error processing your credit card, please try again.');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_ERROR', 'Credit Card Error!');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_PAYTYPE', 'Payment Method:');
?>
